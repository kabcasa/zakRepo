import xbmc
xbmc.executebuiltin('RunAddon(plugin.video.Legacy)')
