# -*- coding: utf-8 -*-
import xbmc,xbmcplugin,xbmcgui,xbmcaddon
addon_id = 'plugin.video.Legazy'
locStr = xbmcaddon.Addon(addon_id)

def translate(text):
      return locStr.getLocalizedString(text)#.encode('utf-8')
################################################

