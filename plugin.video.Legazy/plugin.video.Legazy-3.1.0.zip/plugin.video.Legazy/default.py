#################################################################################
import xbmc,xbmcaddon,xbmcgui,xbmcplugin,xbmcvfs
import base64,os,re,unicodedata,time,string,sys,urllib,json,datetime,zipfile,shutil
import requests
from resources.modules import client,control,tools,shortlinks,login,plugintools
from resources.language import translate
from datetime import date
import xml.etree.ElementTree as ElementTree

#reload(sys)
#sys.setdefaultencoding('utf8')

#################################################################################
addon_id     = 'plugin.video.Legazy'
selfAddon    = xbmcaddon.Addon(id=addon_id)
addonInfo    = xbmcaddon.Addon().getAddonInfo
dataPath     = xbmcvfs.translatePath(addonInfo('profile'))
userdata     = xbmcvfs.translatePath('special://home/userdata/')
THUMBNAILS   = xbmcvfs.translatePath(os.path.join(userdata,'Thumbnails'))
advanced_settings =  xbmcvfs.translatePath('special://home/addons/'+addon_id+'/resources/advanced_settings')
icon            = xbmcvfs.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
fanart          = xbmcvfs.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
icon_account    = xbmcvfs.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/art', 'account_info.png'))
icon_live       = xbmcvfs.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/art', 'live_tv_nora.png'))
icon_movies     = xbmcvfs.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/art', 'movies.png'))
icon_series     = xbmcvfs.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/art', 'serise_nora.png'))
icon_catch_up   = xbmcvfs.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/art', 'catch_up_nora.png'))
icon_settings   = xbmcvfs.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/art', 'settings_nora.png'))
icon_clear_data = xbmcvfs.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/art', 'update_nora.png'))
icon_pvr        = xbmcvfs.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/art', 'pvr_icon.png'))
icon_epg        = xbmcvfs.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/art', 'epg.png'))
AUTOEXE0  = xbmcvfs.translatePath(os.path.join('special://home/addons/' + addon_id, 'autoexec.py'))
GUISETTINGS = xbmcvfs.translatePath(os.path.join(userdata,'guisettings.xml'))
AUTOEXE = xbmcvfs.translatePath(os.path.join(userdata,'autoexec.py'))
CACHE =  xbmcvfs.translatePath(os.path.join('special://home/userdata/addon_data/' + addon_id,'cache'))
LIVETVD =  xbmcvfs.translatePath(os.path.join(CACHE,'livetvd'))
MOVIED =  xbmcvfs.translatePath(os.path.join(CACHE,'movied'))
SERIED =  xbmcvfs.translatePath(os.path.join(CACHE,'seried'))
Guide = xbmcvfs.translatePath(os.path.join(CACHE, 'guide.xml'))
Guides = xbmcvfs.translatePath(os.path.join(CACHE, 'guides.xml'))
GuideLoc = xbmcvfs.translatePath(os.path.join(CACHE, 'g'))
GLIST = xbmcvfs.translatePath(os.path.join(CACHE, 'glist.txt'))
Fthumb = xbmcvfs.translatePath(os.path.join(CACHE, 'fthumb.json'))
Fname = xbmcvfs.translatePath(os.path.join(CACHE, 'fname.json'))

global username, password,code,server, live_url, vod_url, ser_url, panel_api, playerapi, play_url
username     = plugintools.get_setting('user')
password     = plugintools.get_setting('Password')
code         = plugintools.get_setting('Code')
server, background, logo = login.auth_code()


#########################################	
def load_requests(source_url, sink_path):
    import requests
    r = requests.get(source_url, stream=True)
    if r.status_code == 200:
        with open(sink_path, 'wb') as f:
            for chunk in r:
                f.write(chunk)

#########################################
load_requests(background,fanart)
load_requests(logo,icon)
tools.deleteThumbnails(THUMBNAILS)
live_url     = '%s/enigma2.php?username=%s&password=%s&type=get_live_categories'%(server,username,password)
vod_url      = '%s/enigma2.php?username=%s&password=%s&type=get_vod_categories'%(server,username,password)
ser_url      = '%s/enigma2.php?username=%s&password=%s&type=get_series_categories'%(server,username,password)
panel_api    = '%s/panel_api.php?username=%s&password=%s'%(server,username,password)
playerapi    = '%s/player_api.php?username=%s&password=%s'%(server,username,password)
play_url     = '%s/live/%s/%s/'%(server,username,password)
epg_url      = '%s/xmltv.php?username=%s&password=%s'%(server,username,password)
pvr_url      = '%s/get.php?username=%s&password=%s&type=m3u_plus&output=ts'%(server,username,password)

boots = plugintools.get_setting("bootup")
if boots == "true" :
        if not os.path.isfile(AUTOEXE):
                shutil.copy(AUTOEXE0, userdata)
else :
        if os.path.isfile(AUTOEXE):
                 os.remove(AUTOEXE)

#########################################                
def home():
        login.auth_user(server)
        sleepwatchdog()
        dircache()
        tools.addDir(translate(30020),'live',1,icon_live,fanart,'')
        tools.addDir(translate(30021),'vod',3,icon_movies,fanart,'')
        tools.addDir(translate(30022),'ser',5,icon_series,fanart,'')
        tools.addDir(translate(30023),'url',12,icon_catch_up,fanart,'')
        tools.addDir(translate(30010),'player',19,icon_account,fanart,'')
        tools.addDir(translate(30024),'url',8,icon_settings,fanart,'')
        tools.addDir(translate(30025),'url',16,icon_clear_data,fanart,'')
        xbmc.executebuiltin('Container.SetViewMode(500)')
			
def settingsmenu():
        icon_gs = xbmcvfs.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/art', 'general_settings.png'))
        icon_tf = xbmcvfs.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/art', 'time_format.png'))
        icon_sf = xbmcvfs.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/art', 'streamformat.png'))
        icon_ep = xbmcvfs.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/art', 'epg.png'))
        icon_pc = xbmcvfs.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/art', 'parental.png'))
        icon_sc = xbmcvfs.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/art', 'internet.png'))
        icon_ps = xbmcvfs.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/art', 'player_settings.png'))
        
        tools.addDir(translate(30026),'GES',10,icon_gs,fanart,'')
        tools.addDir(translate(30027),'LES',10,icon_gs,fanart,'')
        tools.addDir(translate(30028),'ST',10,icon_sf,fanart,'')
        tools.addDir(translate(30029),'TIF',10,icon_tf,fanart,'')
        #tools.addDir(translate(30030),'EPT',10,icon_ep,fanart,'')
        tools.addDir(translate(30031),'PAR',10,icon_pc,fanart,'')
        tools.addDir(translate(30032),'SK',10,icon_sc,fanart,'')
        xbmc.executebuiltin('Container.SetViewMode(500)')

def writeAdvanced(val):
        with open(GUISETTINGS, 'r') as f:
                content = f.read()
       
        match = re.findall('setting id="locale.use.*?hourclock">(\d+)hours</setting>',content)[0]
        xbmcgui.Dialog().ok("", str(match) )
        if val == "0" :
                if match  == "24" :
                        content = content.replace('<setting id="locale.use24hourclock">24hours</setting>','<setting id="locale.use24hourclock">12hours</setting>')
                        with open(GUISETTINGS, 'w') as f:
                                f.write(content)
        elif val == "1" :
                if match  == "12" :
                        content = content.replace('<setting id="locale.use24hourclock">12hours</setting>','<setting id="locale.use24hourclock">24hours</setting>')
                        with open(GUISETTINGS, 'w') as f:
                                f.write(content)

	
def addonsettings(url,description):
        if   url =="CC":
                tools.clear_cache()
        elif url =="PAR":
                parentalpopup()
        elif url =="GES":
                streamlist = ["Yes","No"]
                streams = plugintools.selector(streamlist,title=translate(30033))
                if "0" in str(streams): plugintools.set_setting("bootup","true")
                

        elif url =="LES":
                streamlist = ["English","Spanish"]
                streams = plugintools.selector(streamlist,title=translate(30027))
                plugintools.set_setting("language",str(streams))
        elif url =="ST":
                streamlist = ["MPEGTS(ts)","HLS(m3u8)"]
                streams = plugintools.selector(streamlist,title=translate(30034))
                plugintools.set_setting("streamf",str(streams))
        elif url =="TIF":
                streamlist = ["12 Hours","24 Hours"]
                streams = plugintools.selector(streamlist,title=translate(30035))
                writeAdvanced(str(streams))
                plugintools.set_setting("timef",str(streams))
                
        elif url =="EPT":
                streamlist = ["All Channels","Only With EPG"]
                streams = plugintools.selector(streamlist,title="Select Show Channels")
                plugintools.set_setting("epgtimeline",str(streams))

        elif url =="SK":
                streamlist = ["Normal","Mobile Devices","Retro"]
                streams = plugintools.selector(streamlist,title=translate(30035))
                plugintools.set_setting("skinc",str(streams))

        elif url =="PLS":
                streamlist = ["1","2"]
                streams = plugintools.selector(streamlist,title="Select Players")
                plugintools.set_setting("players",str(streams))


###################################################################		
def userpopup():
	kb =xbmc.Keyboard ('', 'heading', True)
	kb.setHeading('Enter Username')
	kb.setHiddenInput(False)
	kb.doModal()
	if (kb.isConfirmed()):
		text = kb.getText()
		return text
	else:
		return False

		
def passpopup():
	kb =xbmc.Keyboard ('', 'heading', True)
	kb.setHeading('Enter Password')
	kb.setHiddenInput(False)
	kb.doModal()
	if (kb.isConfirmed()):
		text = kb.getText()
		return text
	else:
		return False

def codepopup():
	kb =xbmc.Keyboard ('', 'heading', True)
	kb.setHeading('Enter Code')
	kb.setHiddenInput(False)
	kb.doModal()
	if (kb.isConfirmed()):
		text = kb.getText()
		return text
	else:
		return False

def parentalpopup():
        pare = plugintools.message_yes_no(translate(30038),text2="",text3="")
        if pare  :  plugintools.set_setting("parentc","true")
        else :
            plugintools.set_setting("parentc","false")
            return
        
        kb =xbmc.Keyboard ("", translate(30031), True)
        kb.setHeading(translate(30103))
        kb.setHiddenInput(False)
        kb.doModal()
        if (kb.isConfirmed()):
                text = kb.getText()
                plugintools.set_setting('parentvalue',str(text))
                return 
        else:
                plugintools.set_setting("parentc","false")
                return 		

def parentalf(name):
        parents = plugintools.get_setting("parentc")
        if parents == 'false' : return
        a = 'XXX', 'Adult', 'Adults','ADULT','ADULTS','adult','adults','Porn','PORN','porn','Porn','xxx'
        if any(s in name for s in a):
           xbmc.executebuiltin((u'XBMC.Notification(translate(30031), translate(30039), 2000)'))
           text = plugintools.keyboard_input(default_text="", title=translate(30031))#Parental lock
           if text == plugintools.get_setting('parentvalue'):
              return
           else:
              exit()
        else:
           name = ""

#def check_required():
def filecache(path):
        if not xbmcvfs.exists(path) : return False
        f = xbmcvfs.File(path)
        s = f.size()
        f.close()
        if s == 0 : return False
        st = xbmcvfs.Stat(path)
        modified = st.st_mtime()
        auj = time.time()
        #dd = int(plugintools.get_setting(vsetting))   
        da =  24*3600
        dif = auj - modified    
        if  dif < da  : return True
        else :
                xbmcvfs.delete(path)
                return False

def dircache():
        if not xbmcvfs.exists(CACHE):
                xbmcvfs.mkdir(CACHE)
                xbmcvfs.mkdir(LIVETVD)
                xbmcvfs.mkdir(MOVIED)
                xbmcvfs.mkdir(SERIED)
             

###################################################################		
def livecategory(url):
        opens = tools.OPEN_URL(live_url)
        all_cats = tools.regex_get_all(str(opens),'<channel>','</channel>')
        for a in all_cats:
                name = tools.regex_from_to(a,'<title>','</title>')
                name = base64.b64decode(name)
                parentalf(name)
                url1  = tools.regex_from_to(a,'<playlist_url>','</playlist_url>').replace('<![CDATA[','').replace(']]>','')
                tools.addDir(name,url1,2,icon,fanart,'')
		
def Livelist(url):
        fileurl = url.split('&')[-1].replace('=','') 
        filepa = xbmcvfs.translatePath(os.path.join(LIVETVD,'%s.xml'%fileurl))
        ressp = filecache(filepa)

        if not ressp :
                topen = tools.OPEN_URL(url)
                with open(filepa, 'w') as f:                
                        f.write(str(topen))
        
        with open(filepa,'r') as f:
                topen2 = f.read()
        all_cats = tools.regex_get_all(topen2,'<channel>','</channel>')
        for a in all_cats:
                name = tools.regex_from_to(a,'<title>','</title>')
                name = base64.b64decode(name)
                parentalf(name)
                xbmc.log(str(name))
                try:
                        name = re.sub('\[.*?min ','-',name)
                except:
                        pass
                thumb= tools.regex_from_to(a,'<desc_image>','</desc_image>').replace('<![CDATA[','').replace(']]>','')
                url1  = tools.regex_from_to(a,'<stream_url>','</stream_url>').replace('<![CDATA[','').replace(']]>','')
                desc = tools.regex_from_to(a,'<description>','</description>')
                desc = base64.b64decode(desc).decode("utf-8")
                desc = desc.replace('[','NOW:[')
                desc = re.sub('\\n(NOW)','\\n\1NEXT',desc).replace('\x01','')
                tools.addDir(name,url1,4,thumb,fanart,desc)
        xbmcplugin.setContent(int(sys.argv[1]), 'movies')	
	
####################################		
def vod(url):
        if url =="vod":
                topen = str(tools.OPEN_URL(vod_url))
                all_cats = tools.regex_get_all(topen,'<channel>','</channel>')
        else:
                fileurl = url.split('&')[-1].replace('=','') 
                filepa = xbmcvfs.translatePath(os.path.join(MOVIED,'%s.xml'%fileurl))
                ressp = filecache(filepa)

                if not ressp :
                        topen = tools.OPEN_URL(url)              
                        with open(filepa, 'w') as f:                
                                f.write(str(topen))


                with open(filepa,'r') as f:
                        topen = f.read()
                all_cats = tools.regex_get_all(topen,'<channel>','</channel>')

        for a in all_cats:
                if '<playlist_url>' in topen:
                        name = tools.regex_from_to(a,'<title>','</title>')
                        parentalf(name)
                        url1  = tools.regex_from_to(a,'<playlist_url>','</playlist_url>').replace('<![CDATA[','').replace(']]>','')
                        tools.addDir(base64.b64decode(name).decode("utf-8").replace('?',''),url1,3,icon,fanart,'')
                else:
                        if xbmcaddon.Addon().getSetting('meta') == 'true':
                                try:
                                        name = tools.regex_from_to(a,'<title>','</title>')
                                        name = base64.b64decode(name).decode("utf-8")
                                        thumb= tools.regex_from_to(a,'<desc_image>','</desc_image>').replace('<![CDATA[','').replace(']]>','')
                                        url  = tools.regex_from_to(a,'<stream_url>','</stream_url>').replace('<![CDATA[','').replace(']]>','')
                                        desc = tools.regex_from_to(a,'<description>','</description>')
                                        desc = base64.b64decode(desc)
                                        plot = tools.regex_from_to(desc,'PLOT:','\n')
                                        cast = tools.regex_from_to(desc,'CAST:','\n')
                                        ratin= tools.regex_from_to(desc,'RATING:','\n')
                                        year = tools.regex_from_to(desc,'RELEASEDATE:','\n').replace(' ','-')
                                        year = re.compile('-.*?-.*?-(.*?)-',re.DOTALL).findall(year)
                                        runt = tools.regex_from_to(desc,'DURATION_SECS:','\n')
                                        genre= tools.regex_from_to(desc,'GENRE:','\n')
                                        tools.addDirMeta(name.replace('[/COLOR].','.[/COLOR]'),url,41,thumb,fanart,plot,str(year).replace("['","").replace("']",""),str(cast).split(),ratin,runt,genre)
                                except:pass
                                xbmcplugin.setContent(int(sys.argv[1]), 'movies')
                        else:
                                name = tools.regex_from_to(a,'<title>','</title>')
                                name = base64.b64decode(name).decode("utf-8")
                                thumb= tools.regex_from_to(a,'<desc_image>','</desc_image>').replace('<![CDATA[','').replace(']]>','')
                                url  = tools.regex_from_to(a,'<stream_url>','</stream_url>').replace('<![CDATA[','').replace(']]>','')
                                desc = tools.regex_from_to(a,'<description>','</description>')
                                tools.addDir(name,url,41,thumb,fanart,base64.b64decode(desc))
                
        xbmcplugin.setContent(int(sys.argv[1]), 'movies')	
##########################################
def ser(url):        
	if url =="ser":
		open = str(tools.OPEN_URL(ser_url))
	else:
		open = str(tools.OPEN_URL(url))
	all_cats = tools.regex_get_all(open,'<channel>','</channel>')
	for a in all_cats:
		if '<playlist_url>' in open:
			name = tools.regex_from_to(a,'<title>','</title>')
			parentalf(name)
			url1  = tools.regex_from_to(a,'<playlist_url>','</playlist_url>').replace('<![CDATA[','').replace(']]>','')
			tools.addDir(base64.b64decode(name).decode("utf-8").replace('?',''),url1,6,icon,fanart,'')
		else:
			if xbmcaddon.Addon().getSetting('meta') == 'true':
				try:
					name = tools.regex_from_to(a,'<title>','</title>')
					name = base64.b64decode(name).decode("utf-8")
					thumb= tools.regex_from_to(a,'<desc_image>','</desc_image>').replace('<![CDATA[','').replace(']]>','')
					url  = tools.regex_from_to(a,'<stream_url>','</stream_url>').replace('<![CDATA[','').replace(']]>','')
					desc = tools.regex_from_to(a,'<description>','</description>')
					desc = base64.b64decode(desc)
					plot = tools.regex_from_to(desc,'PLOT:','\n')
					cast = tools.regex_from_to(desc,'CAST:','\n')
					ratin= tools.regex_from_to(desc,'RATING:','\n')
					year = tools.regex_from_to(desc,'RELEASEDATE:','\n').replace(' ','-')
					year = re.compile('-.*?-.*?-(.*?)-',re.DOTALL).findall(year)
					runt = tools.regex_from_to(desc,'DURATION_SECS:','\n')
					genre= tools.regex_from_to(desc,'GENRE:','\n')
					tools.addDirMeta(str(name).replace('[/COLOR].','.[/COLOR]'),url,6,thumb,fanart,plot,str(year).replace("['","").replace("']",""),str(cast).split(),ratin,runt,genre)
				except:pass
				xbmcplugin.setContent(int(sys.argv[1]), 'movies')
			else:
				name = tools.regex_from_to(a,'<title>','</title>')
				name = base64.b64decode(name).decode("utf-8")
				parentalf(name)
				thumb= tools.regex_from_to(a,'<desc_image>','</desc_image>').replace('<![CDATA[','').replace(']]>','')
				url  = tools.regex_from_to(a,'<stream_url>','</stream_url>').replace('<![CDATA[','').replace(']]>','')
				desc = tools.regex_from_to(a,'<description>','</description>')
				tools.addDir(name,url,6,thumb,fanart,base64.b64decode(desc))
			xbmcplugin.setContent(int(sys.argv[1]), 'movies')

def sercat(url):
        fileurl = url.split('&')[-1].replace('=','') 
        filepa = xbmcvfs.translatePath(os.path.join(SERIED,'%s.json'%fileurl))
        ressp = filecache(filepa)
        if not ressp :
                url = url.replace('enigma2','player_api').replace('type','action')
                content = urllib.request.urlopen(url)
                with open(filepa, 'w') as f:                
                        json.dump(json.load(content),f) 
        
        with open(filepa,'r') as f:
                jcontent = json.load(f)

        for x in jcontent :#)all_cats:
                name = x["name"]
                parentalf(name)
                thumb= x["cover"]
                rating = x["rating"]
                plot = x["plot"]
                cast = x["cast"]
                releaseDate= x["releaseDate"]
                url = x["series_id"]
                runtime = x["episode_run_time"]
                genre= x["genre"]
                desc = str(cast) + '\n'+str(genre)+'  '+str(releaseDate)+'  '+str(runtime)+'  '+str(rating)+'\n'+str(plot)
                tools.addDir(str(name),str(url),11,thumb,fanart,str(desc))#cast.split() + '\n'+
        xbmcplugin.setContent(int(sys.argv[1]), 'movies')


def sersais(url,iconimage):
        link = '%s/enigma2.php?username=%s&password=%s&type=get_seasons&series_id=%s'%(server,username,password,url)
        topen = str(tools.OPEN_URL(link))
                
        all_cats = tools.regex_get_all(topen,'<channel>','</channel>')
        for a in all_cats:
                if '<playlist_url>' in topen:
                        name = tools.regex_from_to(a,'<title>','</title>')
                        url1  = tools.regex_from_to(a,'<playlist_url>','</playlist_url>').replace('<![CDATA[','').replace(']]>','')
                        thumb = iconimage
                        tools.addDir(base64.b64decode(name).decode("utf-8").replace('?',''),url1,15,thumb,fanart,'')
        xbmcplugin.setContent(int(sys.argv[1]), 'movies')

def serepi(url):        
        topen = str(tools.OPEN_URL(url))		
        all_cats = tools.regex_get_all(topen,'<channel>','</channel>')
        for a in all_cats:
                if '1':
                        name = tools.regex_from_to(a,'<title>','</title>')
                        name = base64.b64decode(name).decode("utf-8")
                        thumb= tools.regex_from_to(a,'<desc_image>','</desc_image>').replace('<![CDATA[','').replace(']]>','')
                        url  = tools.regex_from_to(a,'<stream_url>','</stream_url>').replace('<![CDATA[','').replace(']]>','')
                        desc = tools.regex_from_to(a,'<description>','</description>')
                        tools.addDir(name,url,41,thumb,fanart,base64.b64decode(desc))
        xbmcplugin.setContent(int(sys.argv[1]), 'movies')
	
##########################################
def catchup():    
    ressp = filecache(Guide)   
    if ressp :
        listcatchup()
        return    
    url = "%s/xmltv.php?username=%s&password=%s"%(server,username,password)
    DownloaderClass(url,GuideLoc + "uide.xml")
    
    try :
        with open(Guide, 'r', encoding='UTF-8') as f:
            content = f.read()#.decode('UTF-8')
            output = content #unicodedata.normalize('NFKD', content).encode('utf-8', 'ignore')
    except Exception as e : #UnicodeDecodeError :
        print("unicodeError",e)
        pass
        

    with open(Guide, 'w', encoding='UTF-8') as f:
        f.write(output)

    listcatchup()		


def listcatchup():
        ressp = filecache(GLIST)
        if not ressp :
                topen = tools.OPEN_URL(panel_api)                
                with open(GLIST,'w') as f :
                        f.write(str(topen))	
        else :
                with open(GLIST,'r') as f :
                        topen = f.read()

        all  = tools.regex_get_all(str(topen),'{"num','direct')
        fic = {}
        fin = {}
        for a in all:
                
                if '"tv_archive":1' in a:
                        name = tools.regex_from_to(a,'"epg_channel_id":"','"')
                        namede = '.' + name.split('.')[-1]
                        parentalf(name)
                        thumb= tools.regex_from_to(a,'"stream_icon":"','"').replace('\\','')			
                        id   = tools.regex_from_to(a,'stream_id":"','"')
                        fic[id] = thumb
                        fin[id] = name
                        namec = name.replace(namede,'')
                        tools.addDir(namec,'url',13,thumb,fanart,id)
        with open(Fthumb, 'w') as fp:
            json.dump(fic, fp)          
        with open(Fname, 'w') as fp:
            json.dump(fin, fp)          
		
def tvarchive(name,description):
    with open(Fthumb, 'r') as fp:
            fic = json.load(fp)          
    with open(Fname, 'r') as fp:
            fin = json.load(fp)          

    thumb = fic[description].replace("\\","")
    name = str(fin[description])
    filename = open(Guide,"r", encoding='utf-8')
    tree = ElementTree.parse(filename)
    pony = "apples"
    import datetime as dt
    from datetime import time
    date3 = datetime.datetime.now() - datetime.timedelta(days=5)
    date = str(date3)
    now = str(datetime.datetime.now()).replace('-','').replace(':','').replace(' ','')
    programmes = tree.findall("programme")
    for programme in programmes:
        if name in programme.attrib.get('channel'):
            showtime = programme.attrib.get('start')
            head, sep, tail = showtime.partition(' +')
            date = str(date).replace('-','').replace(':','').replace(' ','')
            year, month, day = showtime.partition('2017')
            kanalinimi = programme.find('title').text + showtime
            day = day[:-6]
            if head > date:
                if head < now:
                    head2 = head
                    head2 = head2[:4] + '/' + head2[4:]
                    head = head[:4] + '-' + head[4:]
                    head2 = head2[:7] + '/' + head2[7:]
                    head = head[:7] + '-' + head[7:]
                    head2 = head2[:10] + ' - ' + head2[10:]
                    head = head[:10] + ':' + head[10:]
                    head2 = head2[:15] + ':' + head2[15:]
                    head = head[:13] + '-' + head[13:]
                    head2 = head2[:-2]
                    head = head[:-2]
                    poo1 = ("%s/streaming/timeshift.php?username=%s&password=%s&stream=%s&start=")%(server,username,password,description)
                    pony = poo1 + str(head) + "&duration=240"
                    head2 = '[COLOR cyan]%s - [/COLOR]'%head2 
                    kanalinimi = str(head2)+ programme.find('title').text
                    desc  = programme.find('desc').text
                    if desc == None : desc = ""
                    tools.addDir(kanalinimi,pony,4,thumb,fanart,desc) #.encode(encoding='UTF-8'))
                    xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
	
					

#####################################################################
def stream_video(url):
        url = str(url).replace('USERNAME',username).replace('PASSWORD',password)
        #liz = xbmcgui.ListItem('', iconImage=iconimage, thumbnailImage=xbmc.getInfoImage("ListItem.Thumb"))
        #liz.setInfo(type='Video', infoLabels={'Title': '', 'Plot': ''})

        liz = xbmcgui.ListItem('')
        liz.setArt({'icon':iconimage,'thumb':xbmc.getInfoImage("ListItem.Thumb")})
        liz.setInfo( "video", {"Title": '',"Plot":''})
	
        liz.setProperty('IsPlayable','true')
        liz.setPath(str(url))
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)

#####################################################################
def stream_movie(url):
        url = url + "|User-Agent=%s"%urllib.parse.quote("Legazy_IPTV_Player_2")
        url = str(url).replace('USERNAME',username).replace('PASSWORD',password)
        liz = xbmcgui.ListItem('')
        liz.setArt({'icon':iconimage,'thumb':xbmc.getInfoImage("ListItem.Thumb")})
        liz.setInfo( "video", {"Title": '',"Plot":''})
	
        liz.setProperty('IsPlayable','true')        
        ok = xbmc.Player().play(url,liz)
        return ok
	
###################################################################################################
def accountinfo(playerapi):
        url = '%s/player_api.php?username=%s&password=%s'%(server,username,password)
        content = requests.get(url)#playerapi)
        jcontent = json.loads(content.text)["user_info"]
        try:
                userv   = jcontent["username"]
                status     = jcontent["status"]
                connects   = jcontent["max_connections"]
                active     = jcontent["active_cons"]
                istrial    = jcontent["is_trial"]
                if istrial == "0" :
                        trial = 'No'
                elif istrial == "1" :
                        trial = 'Yes'
                expiry     = jcontent["exp_date"]
                if expiry == None :
                        expiry = "Never"
                else :
                        expiry     = datetime.datetime.fromtimestamp(int(expiry)).strftime('%d/%m/%Y - %H:%M')
                tools.addDir('[COLOR cyan]Username :[/COLOR] '+userv,' ',' ',icon,fanart,'')
                tools.addDir('[COLOR cyan]Expiry Date:[/COLOR] '+expiry,'',' ',icon,fanart,'')
                tools.addDir('[COLOR cyan]Account Status :[/COLOR] %s'%status,'',' ',icon,fanart,'')
                tools.addDir('[COLOR cyan]Trial :[/COLOR] %s'%trial,'',' ',icon,fanart,'')
                tools.addDir('[COLOR cyan]Current Connections:[/COLOR] '+ active,'',' ',icon,fanart,'')
                tools.addDir('[COLOR cyan]Allowed Connections:[/COLOR] '+connects,'',' ',icon,fanart,'')
        except:pass

###################################################################################################
def clear_cache(url) :
        confirm = plugintools.message_yes_no("LEGAZY",text2=translate(30040))
        if confirm:
                tools.clear_cac(CACHE)
                dircache()
                plugintools.message("LEGAZY",translate(30041))

        return
###################################################################################################
def DownloaderClass(url, dest):
    dp = xbmcgui.DialogProgress()
    dp.create('Fetching latest Catch Up',"Fetching latest Catch Up...")
    dp.update(0)
    start_time=time.time()
    urllib.request.urlretrieve(url, dest, lambda nb, bs, fs: _pbhook(nb, bs, fs, dp, start_time))

def _pbhook(numblocks, blocksize, filesize, dp, start_time):
        try: 
            percent = min(numblocks * blocksize * 100 / filesize, 100) 
            currently_downloaded = float(numblocks) * blocksize / (1024 * 1024) 
            kbps_speed = numblocks * blocksize / (time.time() - start_time) 
            if kbps_speed > 0: 
                eta = (filesize - numblocks * blocksize) / kbps_speed 
            else: 
                eta = 0 
            kbps_speed = kbps_speed / 1024 
            mbps_speed = kbps_speed / 1024 
            total = float(filesize) / (1024 * 1024) 
            mbs = '[COLOR white]%.02f MB of less than 5MB[/COLOR]' % (currently_downloaded)
            e = '[COLOR white]Speed:  %.02f Mb/s ' % (mbps_speed)  + '[/COLOR]'
            dp.update(int(percent), mbs + "\n" + e)
        except Exception as e :
            print("downlaoad error ",str(e))
            percent = 100 
            dp.update(percent) 
        if dp.iscanceled():
            dialog = xbmcgui.Dialog()
            dialog.ok("LEGAZY", translate(30115))
				
            sys.exit()
            dp.close()
           
def sleepwatchdog():
        if plugintools.get_setting("setwatchdog") == 'true': return
        addon = xbmcaddon.Addon('service.sleepy.watchdog')
        sleepw = xbmcaddon.Addon('service.sleepy.watchdog')
        sleepw.setSetting(id='showPopup', value="true")
        sleepw.setSetting(id='maxIdleTime', value="300 min")
        sleepw.setSetting(id='timeframe', value="0")
        sleepw.setSetting(id='notificationTime', value="60 sec")
        sleepw.setSetting(id='action', value="0")
        plugintools.set_setting("setwatchdog","true") 
        xbmc.executebuiltin("Container.Refresh")

###################################################################################################

params=tools.get_params()
url=None
name=None
mode=None
iconimage=None
description=None
query=None
type=None

try:
	url=urllib.parse.unquote_plus(params["url"])
except:
	pass
try:
	name=urllib.parse.unquote_plus(params["name"])
except:
	pass
try:
	iconimage=urllib.parse.unquote_plus(params["iconimage"])
except:
	pass
try:
	mode=int(params["mode"])
except:
	pass
try:
	description=urllib.parse.unquote_plus(params["description"])
except:
	pass
try:
	query=urllib.parse.unquote_plus(params["query"])
except:
	pass
try:
	type=urllib.parse.unquote_plus(params["type"])
except:
	pass

if mode==None or url==None or len(url)<1:
	home()

elif mode==1:
	livecategory(url)
	
elif mode==2:
	Livelist(url)
	
elif mode==3:
	vod(url)
elif mode==5:
	ser(url)	
elif mode==4:
	stream_video(url)

elif mode==41:
	stream_movie(url)	
elif mode==50:
	search()
	
elif mode==6:
	sercat(url)
	
elif mode==11:
	sersais(url,iconimage)
elif mode==15:
	serepi(url)	
elif mode==8:
	settingsmenu()
	
elif mode==9:
	xbmc.executebuiltin('ActivateWindow(busydialog)')
	tools.Trailer().play(url) 
	xbmc.executebuiltin('Dialog.Close(busydialog)')
	
elif mode==10:
	addonsettings(url,description)

elif mode==19:
	accountinfo(url)


	
elif mode==12:
	catchup()

elif mode==13:
	tvarchive(name,description)
	
elif mode==14:
	listcatchup2()
elif mode==16:
	clear_cache(url)
	


xbmcplugin.endOfDirectory(int(sys.argv[1]))
