import xbmcgui,xbmc, json
from resources.modules import tools,plugintools
from resources.language import translate

AddonTitle   = "LEGAZY"

def auth_code():
    C = plugintools.get_setting('CODE')
    if C == "":       
        msg1 = str(translate(30104))
        msg2 = str(translate(30113))
        yes_pressed = xbmcgui.Dialog().yesno(
            AddonTitle + " - " + str(translate(30105)), msg1+ "\n"+ msg2)
        if yes_pressed:
            get_code()
            server, background, logo = auth_code()
            return server, background, logo 
        else:
            exit()

    else:

        url = 'http://control.legazy.online/legazycontrol/validador.php?usera=%s&type=kodi'%C
        resp = tools.OPEN_URL(url)
        jresp = json.loads(resp)
        if jresp['token'] != 'OK' :
            get_code()
            server, background, logo = auth_code()
            return server, background, logo 
        else :
            serv = jresp['servers']
            background = jresp['background']
            logo = jresp['logo']
            return serv,background,logo

def auth_user(server):
    global server2
    server2 = server
    uuu = plugintools.get_setting('user')
    P = plugintools.get_setting('PASSWORD')
    #C = plugintools.get_setting('CODE')
    if uuu == "" or P == "" :
        
        msg1 = translate(30104) 
        msg2 = translate(30106)
        yes_pressed = xbmcgui.Dialog().yesno(
            AddonTitle + " - " + translate(30105), msg1+ "\n"+ msg2)
        if yes_pressed:
            doLogin()
        else:
            exit()

    else:
        url = '%s/player_api.php?username=%s&password=%s'%(server,uuu, P)
        auth = tools.OPEN_URL(url)
        if  auth != "": 
            pass
        else :
            yes_pressed = xbmcgui.Dialog().yesno(
                AddonTitle, translate(30107))
            if yes_pressed:
                doLogin()
            else :
                exit()  


def doLogin():
    get_username()
    get_password()
    #get_code()

    #xbmcgui.Dialog().ok(AddonTitle, U )
    auth_user(server2)


def get_username():
    try:
        USERNAME = get_username_from_user()
        if USERNAME == "":
            xbmcgui.Dialog().ok(AddonTitle, translate(30108))
            get_username()
        else:
            plugintools.set_setting("user", USERNAME)
            return
    except:
        exit()#get_username()


def get_password():
    try:
        PASSWORD = get_password_from_user()
        if PASSWORD == "":
            xbmcgui.Dialog().ok(AddonTitle, translate(30109))
            get_password()
        else:
            plugintools.set_setting("PASSWORD", PASSWORD)
            return
    except:
        exit()#get_password()

def get_code():
    try:
        CODE = get_code_from_user()
        if CODE == "":
            xbmcgui.Dialog().ok(AddonTitle, translate(30110))
            get_code()
        else:
            plugintools.set_setting("CODE", CODE)
            return
    except:
        exit()#get_password()


def get_username_from_user():
    keyboard = xbmc.Keyboard(
        "", AddonTitle + ", " + translate(30101), False)
    keyboard.doModal()
    if keyboard.isConfirmed():
        pwd = keyboard.getText()
        return pwd
    else :       
        exit()


def get_password_from_user():
    keyboard = xbmc.Keyboard(
        "", AddonTitle + ", " + translate(30102), False)
    keyboard.doModal()
    if keyboard.isConfirmed():
        pwd = keyboard.getText()
        return pwd
    else:
        exit()

def get_code_from_user():
    keyboard = xbmc.Keyboard(
        "", AddonTitle + ", " + translate(30103), False)
    keyboard.doModal()
    if keyboard.isConfirmed():
        pwd = keyboard.getText()
        return pwd
    else:
        exit()
