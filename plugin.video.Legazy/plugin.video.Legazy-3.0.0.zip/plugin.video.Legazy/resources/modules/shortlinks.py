import xbmc,xbmcgui
from resources.modules import plugintools,tools


username     = plugintools.get_setting('user')
password     = plugintools.get_setting('Password')
code         = plugintools.get_setting('Code')
def Get():
	xbmc.executebuiltin("ActivateWindow(busydialog)")
	m3u  = 'http://shacktv.com%3A8080%2Fget.php%3Fusername%3D'+username+'%26password%3D'+password+'%26type%3Dm3u_plus%26output%3Dts'
	epg  = 'http://shacktv.com%3A8080%2Fxmltv.php%3Fusername%3D'+username+'%26password%3D'+password
	#auth = '%s:%s/player_api.php?username=%s&password=%s&code=%s'%(host,port,username,password,code)
	#auth = tools.OPEN_URL(auth)
	if 1:
		request  = 'https://tinyurl.com/create.php?source=indexpage&url='+m3u+'&submit=Make+TinyURL%21&alias='
		xbmc.log(str(request))
		request2 = 'https://tinyurl.com/create.php?source=indexpage&url='+epg+'&submit=Make+TinyURL%21&alias='
		m3u = tools.OPEN_URL(request)
		epg = tools.OPEN_URL(request2)
		xbmc.log(str(epg))
		shortm3u = tools.regex_from_to(m3u,'<div class="indent"><b>','</b>')
		shortepg = tools.regex_from_to(epg,'<div class="indent"><b>','</b>')
		xbmc.executebuiltin("Dialog.Close(busydialog)")
		xbmcgui.Dialog().ok('Legazy','[COLOR cornsilk]M3U URL: [/COLOR]%s'%shortm3u,'','[COLOR cornsilk]EPG URL: [/COLOR]%s'%shortepg)
	else:
		return
